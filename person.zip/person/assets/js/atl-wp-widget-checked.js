jQuery(document).ready(function(){
    console.log("F");
    jQuery('#btn_on').click(function(e) {
        console.log("F");
    })

    jQuery('#checkbox').click(function(){
        console.log("F");
        if (jQuery(this).is(':checked')){
            jQuery('.form-widget-person input:checkbox').prop('checked', true);
        } else {
            jQuery('.form-widget-person input:checkbox').prop('checked', false);
        }
    });



})